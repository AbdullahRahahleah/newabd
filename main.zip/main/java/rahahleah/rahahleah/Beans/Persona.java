package rahahleah.rahahleah.Beans;
public class Persona {
	private String personaType;

	public String getPersonaType() {
		return personaType;
	}

	public void setPersonaType(String personaType) {
		this.personaType = personaType;
	}

	public Persona() {
	}
}