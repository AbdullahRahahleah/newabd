package rahahleah.rahahleah.test;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.Principal;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.AsyncContext;
import javax.servlet.DispatcherType;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;

import rahahleah.rahahleah.Model.Filter;

public class TestFilter {

	@Test
	public void testGenerateJsonParametersToUrl(){
		Map<String,String> Keys = new HashMap<String, String>();
		Keys.put("Key1", "value1");
		Keys.put("Key2", "value 2");
		Keys.put("Key3", "value-3");
		assertEquals("sucessfully generated a new Json URL with addding a specifed parameters)",
		"Key2=value+2&Key1=value1&Key3=value-3",Filter.generateJsonParametersToUrl(Keys));		
	}
	
	@Test
	public void testDisplayJsonToPage() throws Exception {
		Map<String,String> Keys = new HashMap<String, String>();
		Keys.put("Key1", "value1");
		Keys.put("Key2", "value 2");
		Keys.put("Key3", "value-3");
		
		String contextRoot="localhost:8080/myApp";
		assertEquals("sucessfully generated a new FULL Json URL with addding a specifed parameters)",
		"localhost:8080/myApp?Key2=value+2&Key1=value1&Key3=value-3",Filter.generateFullJsonURL(contextRoot, Keys));		
	}
	@Test
	public void testFillParameters(){
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("User_id", "value1");
		request.addParameter("Name", "value2");		
		assertEquals("sucessfully fill the request parameters to new hashMap)",
				2,Filter.fillParameters(request).size());		
	}
}
